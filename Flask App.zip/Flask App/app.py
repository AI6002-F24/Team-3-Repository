from flask import Flask, render_template, request, redirect, url_for, send_from_directory
import os
from ultralytics import YOLO
from PIL import Image
import shutil, glob

# Initialize Flask app
app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploads'
PROCESSED_FOLDER = 'static/processed'

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['PROCESSED_FOLDER'] = PROCESSED_FOLDER

# Load YOLOv8 model
model = YOLO('best_yolov8n.pt')

def recreate_folders():
    """Delete and recreate upload and output folders."""
    for folder in [UPLOAD_FOLDER, PROCESSED_FOLDER]:
        if os.path.exists(folder):
            shutil.rmtree(folder)  # Delete the folder
        os.makedirs(folder)  # Recreate the folder

# Call the function to ensure folders are fresh


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Handle file upload
        if 'file' not in request.files:
            return 'No file part'
        file = request.files['file']
        if file.filename == '':
            return 'No selected file'
        if file:
            recreate_folders()
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            print(file_path)
            file.save(file_path)
            
            run_model(file_path)    

            return redirect(url_for('display_results'))
    return render_template('index.html')

@app.route('/results')
def display_results():
    # Get all .jpg files in the 'processed' folder
    files = glob.glob('static/processed/*.jpg')
    files.sort()  # Ensure files are sorted (optional)
    print(files)
    # Extract only filenames (without the path)
    filenames = [os.path.basename(file) for file in files]
    print(filenames)


    # Render the results template with the filenames
    return render_template('results.html', files=filenames)


def run_model(image_path):
    results = model.predict(image_path)
    results[0].save('static/processed/Detected_Image.jpg')

    best_detections = {}

    for detection in results[0].boxes:
        # Extract class, confidence, and bounding box tensor
        cls = int(detection.cls.item())  # Convert class tensor to int
        conf = detection.conf.item()     # Confidence score
        bbox = detection.xyxy.squeeze().tolist()   # Bounding box coordinates (x1, y1, x2, y2)

        # Update the dictionary with the highest confidence detection per class
        if cls not in best_detections or conf > best_detections[cls]["conf"]:
            best_detections[cls] = {"conf": conf, "bbox": bbox}

    # Class names according to the indices
    class_names = ['AcNo', 'Amt', 'AmtWords', 'ChqNo', 'DateIss', 'IssueBank', 'ReceiverName', 'Sign']

    # Directory to save the cropped images
    output_dir = 'static/processed/'

    # Loop through each detection and save the cropped region
    for cls, detection in best_detections.items():
        cls_index = cls
        bbox = detection['bbox']

        # Round the bounding box coordinates to integer values
        x1, y1, x2, y2 = map(int, bbox)
        image = Image.open(image_path)
        # Crop the region from the image
        cropped_image = image.crop((x1, y1, x2, y2))

        # Get the class name for naming the file
        class_name = class_names[cls_index]

        # Save the cropped image
        cropped_image_path = f"{output_dir}Extracted_{class_name}.jpg"
        cropped_image.save(cropped_image_path)
        print(f"Cropped region for {class_name} saved to {cropped_image_path}")


if __name__ == '__main__':
    app.run(debug=True)
